import { useState, useEffect } from "react";
import { ApiMatch, StreamServer } from "../services/api";

interface StreamPlayerProps {
  selectedMatch: ApiMatch | null;
}

export default function StreamPlayer({ selectedMatch }: StreamPlayerProps) {
  const [activeStream, setActiveStream] = useState<StreamServer | null>(null);

  // Reset stream when a different match is selected
  useEffect(() => {
    setActiveStream(null);
  }, [selectedMatch?.id]);

  if (!selectedMatch) {
    return (
      <section className="mt-8">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-8 text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-slate-700 to-slate-600 flex items-center justify-center">
            <svg className="w-10 h-10 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">No Match Selected</h3>
          <p className="text-slate-400 text-sm max-w-md mx-auto">
            Select a match from the live or upcoming section below, then choose a streaming server to watch.
          </p>
        </div>
      </section>
    );
  }

  const isLive = selectedMatch.status === "live";
  const hasStreams = selectedMatch.iframes && selectedMatch.iframes.length > 0;

  return (
    <section className="mt-8">
      <div className="rounded-2xl overflow-hidden border border-white/10 bg-slate-900/50">
        {/* Match info bar */}
        <div className="flex items-center justify-between px-5 py-3 bg-white/5 border-b border-white/10 flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <span
              className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-white ${
                isLive ? "bg-red-600 animate-pulse" : selectedMatch.status === "finished" ? "bg-slate-600" : "bg-indigo-600"
              }`}
            >
              {selectedMatch.status === "finished" ? "✅ FT" : isLive ? "🔴 LIVE" : "⏳ UPCOMING"}
            </span>
            <span className="text-sm font-medium text-slate-300">{selectedMatch.league}</span>
          </div>
          <div className="flex items-center gap-3">
            {selectedMatch.minute && (
              <span className="flex items-center gap-1.5 text-red-400 text-sm font-semibold">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                </span>
                {selectedMatch.minute}
              </span>
            )}
            {hasStreams && (
              <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
                {selectedMatch.iframes.length} stream{selectedMatch.iframes.length > 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>

        {/* Player area */}
        <div className="relative bg-slate-950">
          {activeStream ? (
            /* Active stream iframe */
            <div className="relative aspect-video">
              <iframe
                src={activeStream.url}
                className="w-full h-full"
                allow="autoplay; fullscreen"
                allowFullScreen
                title={`Stream: ${selectedMatch.homeTeam} vs ${selectedMatch.awayTeam}`}
              ></iframe>
              {/* Overlay for close button */}
              <div className="absolute top-3 left-3 z-10">
                <button
                  onClick={() => setActiveStream(null)}
                  className="px-3 py-1.5 rounded-lg bg-black/60 backdrop-blur-sm text-white text-xs font-medium hover:bg-black/80 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                  Close Stream
                </button>
              </div>
              <div className="absolute top-3 right-3 z-10 px-2.5 py-1 rounded-lg bg-emerald-600/80 backdrop-blur-sm text-white text-xs font-semibold">
                {activeStream.server}
              </div>
            </div>
          ) : hasStreams ? (
            /* Stream selection screen */
            <div className="aspect-video flex flex-col items-center justify-center p-8">
              <div className="text-center mb-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/25">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
                <p className="text-white font-bold text-xl mb-1">
                  {selectedMatch.homeTeam}
                </p>
                <div className="flex items-center justify-center gap-3 my-2">
                  {selectedMatch.homeScore !== undefined ? (
                    <>
                      <span className="text-3xl font-extrabold text-white">{selectedMatch.homeScore}</span>
                      <span className="text-xl font-bold text-slate-500">-</span>
                      <span className="text-3xl font-extrabold text-white">{selectedMatch.awayScore}</span>
                    </>
                  ) : (
                    <span className="text-xl font-bold text-slate-400">VS</span>
                  )}
                </div>
                <p className="text-white font-bold text-xl mb-3">
                  {selectedMatch.awayTeam}
                </p>
                <p className="text-slate-400 text-sm">Choose a stream server to start watching:</p>
              </div>

              {/* Stream server buttons */}
              <div className="flex flex-wrap gap-2 justify-center max-w-lg">
                {selectedMatch.iframes.map((iframe, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveStream(iframe)}
                    className="px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-sm transition-all duration-200 shadow-lg shadow-emerald-600/25 hover:shadow-emerald-500/40 hover:scale-105 cursor-pointer flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M8 5v14l11-7z" />
                    </svg>
                    {iframe.server}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* No streams available */
            <div className="aspect-video flex flex-col items-center justify-center p-8">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-slate-700 to-slate-600 flex items-center justify-center">
                <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </div>
              <div>
                <p className="text-white font-semibold text-lg mb-1">
                  {selectedMatch.homeTeam} vs {selectedMatch.awayTeam}
                </p>
                <p className="text-slate-400 text-sm text-center max-w-sm">
                  {selectedMatch.status === "upcoming"
                    ? `This match starts at ${selectedMatch.time}. Stream links will appear when the match goes live.`
                    : "No stream links available for this match yet. Check back soon or try a different match."}
                </p>
              </div>
              {selectedMatch.status === "upcoming" && (
                <span className="mt-4 px-4 py-1.5 rounded-full bg-indigo-600/30 text-indigo-300 text-sm font-medium border border-indigo-600/40">
                  ⏰ {selectedMatch.time}
                </span>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

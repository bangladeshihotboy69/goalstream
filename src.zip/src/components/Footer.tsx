export default function Footer() {
  const leagues = [
    "Premier League", "La Liga", "Bundesliga", "Serie A",
    "Ligue 1", "Champions League", "Europa League", "Eredivisie",
  ];

  return (
    <footer className="border-t border-white/10 bg-slate-900/50 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center">
                <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2L3 7v6c0 5.6 3.8 10.7 9 12 5.2-1.3 9-6.4 9-12V7l-9-5z" />
                </svg>
              </div>
              <span className="text-lg font-bold text-white">
                Goal<span className="text-emerald-400">Stream</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              Your directory for free football streaming. Find the best sources to watch live matches from leagues around the world.
            </p>
          </div>

          {/* Leagues */}
          <div>
            <h4 className="font-semibold text-white mb-3">Top Leagues</h4>
            <ul className="space-y-2">
              {leagues.slice(0, 4).map((league) => (
                <li key={league}>
                  <a href="#" className="text-sm text-slate-400 hover:text-emerald-400 transition-colors">
                    {league}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* More Leagues */}
          <div>
            <h4 className="font-semibold text-white mb-3">More Leagues</h4>
            <ul className="space-y-2">
              {leagues.slice(4).map((league) => (
                <li key={league}>
                  <a href="#" className="text-sm text-slate-400 hover:text-emerald-400 transition-colors">
                    {league}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white mb-3">Quick Links</h4>
            <ul className="space-y-2">
              {["Live Matches", "Schedule", "Streaming Sources", "FAQ"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-sm text-slate-400 hover:text-emerald-400 transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-slate-500">
            © {new Date().getFullYear()} GoalStream. For informational purposes only. We do not host any streams.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="text-sm text-slate-500 hover:text-slate-300 transition-colors">Privacy</a>
            <a href="#" className="text-sm text-slate-500 hover:text-slate-300 transition-colors">Terms</a>
            <a href="#" className="text-sm text-slate-500 hover:text-slate-300 transition-colors">Contact</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { ApiMatch } from "../services/api";

interface LiveMatchesProps {
  matches: ApiMatch[];
  onSelectMatch: (match: ApiMatch) => void;
  selectedMatch: ApiMatch | null;
  title?: string;
  emptyLabel?: string;
}

const leagueColors: Record<string, string> = {
  "Premier League": "from-purple-500 to-indigo-600",
  "La Liga": "from-red-500 to-orange-600",
  "Bundesliga": "from-red-600 to-rose-700",
  "Serie A": "from-blue-500 to-cyan-600",
  "Ligue 1": "from-cyan-500 to-blue-600",
  "Eredivisie": "from-orange-500 to-amber-600",
  "Brasileirão": "from-green-500 to-lime-600",
  "Saudi Pro League": "from-green-500 to-emerald-700",
  "AFC Asian Cup U17": "from-yellow-500 to-amber-600",
  "1. liga": "from-blue-500 to-indigo-600",
  "EFL League One": "from-slate-500 to-zinc-600",
  "Football": "from-emerald-500 to-teal-600",
};

function getLeagueColor(league: string): string {
  for (const [key, color] of Object.entries(leagueColors)) {
    if (league.toLowerCase().includes(key.toLowerCase())) return color;
  }
  return "from-slate-500 to-slate-600";
}

export default function LiveMatches({ matches, onSelectMatch, selectedMatch, title }: LiveMatchesProps) {
  const isFinished = matches.length > 0 && matches[0]?.status === "finished";
  const heading = title || (isFinished ? "✅ Recent Results" : "🔥 Live Matches");
  const badgeLabel = isFinished ? "FT" : "LIVE";
  const badgeColor = isFinished
    ? "bg-slate-600/20 text-slate-400 border-slate-600/30"
    : "bg-red-600/20 text-red-400 border-red-600/30";

  return (
    <section id="live">
      <div className="flex items-center gap-3 mb-5">
        <h2 className="text-2xl font-bold text-white">{heading}</h2>
        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold border ${badgeColor}`}>
          {matches.length} {badgeLabel}
        </span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {matches.map((match) => (
          <button
            key={match.id}
            onClick={() => onSelectMatch(match)}
            className={`group relative text-left w-full rounded-2xl border p-5 transition-all duration-300 cursor-pointer ${
              selectedMatch?.id === match.id
                ? "bg-emerald-600/20 border-emerald-500/50 shadow-lg shadow-emerald-500/10"
                : "bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20"
            }`}
          >
            {/* League Badge */}
            <div className="flex items-center justify-between mb-3">
              <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-white bg-gradient-to-r ${getLeagueColor(match.league)}`}>
                {match.league}
              </span>
              {match.status === "finished" ? (
                <span className="flex items-center gap-1.5 text-slate-400 text-xs font-semibold">
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  FT
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-red-400 text-xs font-semibold">
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-red-500"></span>
                  </span>
                  LIVE
                </span>
              )}
            </div>

            {/* Teams & Score */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1 text-center min-w-0">
                <div className="w-10 h-10 mx-auto mb-1.5 rounded-full bg-white/10 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {match.homeTeam.substring(0, 3).toUpperCase()}
                </div>
                <p className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors leading-tight truncate">
                  {match.homeTeam}
                </p>
              </div>

              <div className="flex-shrink-0">
                <div className="px-4 py-2 rounded-xl bg-white/10 backdrop-blur-sm">
                  <span className="text-xl font-bold text-white tabular-nums tracking-tight">
                    {match.homeScore ?? "-"}
                  </span>
                  <span className="text-slate-500 mx-1">-</span>
                  <span className="text-xl font-bold text-white tabular-nums tracking-tight">
                    {match.awayScore ?? "-"}
                  </span>
                </div>
              </div>

              <div className="flex-1 text-center min-w-0">
                <div className="w-10 h-10 mx-auto mb-1.5 rounded-full bg-white/10 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {match.awayTeam.substring(0, 3).toUpperCase()}
                </div>
                <p className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors leading-tight truncate">
                  {match.awayTeam}
                </p>
              </div>
            </div>

            {/* Stream count */}
            {match.iframes.length > 0 && (
              <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-center gap-1.5 text-emerald-400 text-xs font-medium">
                <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
                {match.iframes.length} stream{match.iframes.length > 1 ? "s" : ""} available
              </div>
            )}

            {/* Selected indicator */}
            {selectedMatch?.id === match.id && (
              <div className="mt-3 pt-3 border-t border-emerald-500/30 flex items-center justify-center gap-1.5 text-emerald-400 text-xs font-medium">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                </svg>
                Selected — pick a stream above
              </div>
            )}
          </button>
        ))}
      </div>
    </section>
  );
}

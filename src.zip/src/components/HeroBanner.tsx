interface HeroBannerProps {
  liveCount?: number;
}

export default function HeroBanner({ liveCount = 0 }: HeroBannerProps) {
  return (
    <section className="relative mt-6 mb-6 overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-700 p-6 sm:p-8">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
          backgroundSize: '32px 32px',
        }}></div>
      </div>
      <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-white/5 blur-3xl"></div>
      <div className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full bg-white/5 blur-3xl"></div>

      <div className="relative flex items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-sm border border-white/30 flex items-center justify-center flex-shrink-0">
            <svg className="w-7 h-7 sm:w-8 sm:h-8 text-white drop-shadow-lg" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2L3 7v6c0 5.6 3.8 10.7 9 12 5.2-1.3 9-6.4 9-12V7l-12-5z" />
            </svg>
          </div>
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-sm text-white text-xs font-medium mb-1.5">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-red-500"></span>
              </span>
              {liveCount > 0
                ? `${liveCount} match${liveCount > 1 ? "es" : ""} live right now`
                : "Loading live data..."}
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Goal<span className="text-yellow-300">Stream</span>
            </h1>
          </div>
        </div>

        {/* Orbiting decoration */}
        <div className="hidden sm:block relative w-24 h-24 flex-shrink-0">
          <div className="absolute inset-0 animate-spin" style={{ animationDuration: '20s' }}>
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-yellow-400 shadow-lg shadow-yellow-400/50"></div>
          </div>
          <div className="absolute inset-0 animate-spin" style={{ animationDuration: '25s', animationDirection: 'reverse' }}>
            <div className="absolute bottom-2 left-1 w-2.5 h-2.5 rounded-full bg-red-400 shadow-lg shadow-red-400/50"></div>
          </div>
          <div className="absolute inset-0 animate-spin" style={{ animationDuration: '18s' }}>
            <div className="absolute top-8 right-1 w-2.5 h-2.5 rounded-full bg-emerald-300 shadow-lg shadow-emerald-300/50"></div>
          </div>
        </div>
      </div>
    </section>
  );
}

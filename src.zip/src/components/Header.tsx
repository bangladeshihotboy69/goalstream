export default function Header() {
  return (
    <header className="border-b border-white/10 bg-slate-900/80 backdrop-blur-xl sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-500/25 group-hover:scale-105 transition-transform">
              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2L3 7v6c0 5.6 3.8 10.7 9 12 5.2-1.3 9-6.4 9-12V7l-9-5z" />
              </svg>
            </div>
            <span className="text-xl font-bold text-white tracking-tight">
              Goal<span className="text-emerald-400">Stream</span>
            </span>
          </a>
        </div>
      </div>
    </header>
  );
}

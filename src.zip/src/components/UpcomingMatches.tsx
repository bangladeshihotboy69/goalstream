import { ApiMatch } from "../services/api";

interface UpcomingMatchesProps {
  matches: ApiMatch[];
  onSelectMatch: (match: ApiMatch) => void;
  selectedMatch: ApiMatch | null;
}

const leagueColors: Record<string, string> = {
  "Premier League": "from-purple-500 to-indigo-600",
  "La Liga": "from-red-500 to-orange-600",
  "Bundesliga": "from-red-600 to-rose-700",
  "Serie A": "from-blue-500 to-cyan-600",
  "Ligue 1": "from-cyan-500 to-blue-600",
  "Eredivisie": "from-orange-500 to-amber-600",
  "Brasileirão": "from-green-500 to-lime-600",
  "Saudi Pro League": "from-green-500 to-emerald-700",
  "AFC Asian Cup U17": "from-yellow-500 to-amber-600",
  "1. liga": "from-blue-500 to-indigo-600",
  "EFL League One": "from-slate-500 to-zinc-600",
  "Football": "from-emerald-500 to-teal-600",
};

function getLeagueColor(league: string): string {
  for (const [key, color] of Object.entries(leagueColors)) {
    if (league.toLowerCase().includes(key.toLowerCase())) return color;
  }
  return "from-slate-500 to-slate-600";
}

export default function UpcomingMatches({ matches, onSelectMatch, selectedMatch }: UpcomingMatchesProps) {
  return (
    <section id="upcoming">
      <div className="flex items-center gap-3 mb-5">
        <h2 className="text-2xl font-bold text-white">📅 Upcoming Matches</h2>
        <span className="px-2.5 py-1 rounded-full bg-indigo-600/20 text-indigo-400 text-xs font-semibold border border-indigo-600/30">
          {matches.length} SCHEDULED
        </span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {matches.map((match) => (
          <button
            key={match.id}
            onClick={() => onSelectMatch(match)}
            className={`group relative text-left w-full rounded-2xl border p-5 transition-all duration-300 cursor-pointer ${
              selectedMatch?.id === match.id
                ? "bg-indigo-600/20 border-indigo-500/50 shadow-lg shadow-indigo-500/10"
                : "bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20"
            }`}
          >
            {/* League Badge */}
            <div className="flex items-center justify-between mb-3">
              <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-white bg-gradient-to-r ${getLeagueColor(match.league)}`}>
                {match.league}
              </span>
              <span className="flex items-center gap-1.5 text-indigo-400 text-xs font-semibold">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {match.time}
              </span>
            </div>

            {/* Teams */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1 text-center min-w-0">
                <div className="w-10 h-10 mx-auto mb-1.5 rounded-full bg-white/10 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {match.homeTeam.substring(0, 3).toUpperCase()}
                </div>
                <p className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors leading-tight truncate">
                  {match.homeTeam}
                </p>
              </div>

              <div className="flex-shrink-0">
                <span className="text-sm font-bold text-slate-400">VS</span>
              </div>

              <div className="flex-1 text-center min-w-0">
                <div className="w-10 h-10 mx-auto mb-1.5 rounded-full bg-white/10 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {match.awayTeam.substring(0, 3).toUpperCase()}
                </div>
                <p className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors leading-tight truncate">
                  {match.awayTeam}
                </p>
              </div>
            </div>

            {/* Time */}
            <div className="mt-3 pt-3 border-t border-white/10">
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Kickoff: {match.time}
              </span>
            </div>

            {/* Stream count */}
            {match.iframes.length > 0 && (
              <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-center gap-1.5 text-emerald-400 text-xs font-medium">
                <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
                {match.iframes.length} stream{match.iframes.length > 1 ? "s" : ""} ready
              </div>
            )}

            {selectedMatch?.id === match.id && (
              <div className="mt-2 pt-2 border-t border-indigo-500/30 flex items-center justify-center gap-1.5 text-indigo-400 text-xs font-medium">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
                Watch when live
              </div>
            )}
          </button>
        ))}
      </div>
    </section>
  );
}

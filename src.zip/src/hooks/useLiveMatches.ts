import { useState, useEffect, useCallback } from "react";
import { ApiMatch, fetchEmbedSportexMatches, fetchAllMatches } from "../services/api";

interface UseLiveMatchesReturn {
  matches: ApiMatch[];
  liveMatches: ApiMatch[];
  upcomingMatches: ApiMatch[];
  finishedMatches: ApiMatch[];
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
  refresh: () => void;
}

export function useLiveMatches(refreshInterval = 45000): UseLiveMatchesReturn {
  const [matches, setMatches] = useState<ApiMatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const loadMatches = useCallback(async () => {
    try {
      setError(null);
      const data = await fetchEmbedSportexMatches();
      if (data.length === 0) {
        const combined = await fetchAllMatches();
        setMatches(combined);
      } else {
        setMatches(data);
      }
      setLastUpdated(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load matches");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadMatches();
    const interval = setInterval(loadMatches, refreshInterval);
    return () => clearInterval(interval);
  }, [loadMatches, refreshInterval]);

  const liveMatches = matches.filter((m) => m.status === "live");
  const upcomingMatches = matches.filter((m) => m.status === "upcoming");
  const finishedMatches = matches.filter((m) => m.status === "finished");

  return {
    matches,
    liveMatches,
    upcomingMatches,
    finishedMatches,
    loading,
    error,
    lastUpdated,
    refresh: loadMatches,
  };
}

import { useState, useEffect, useRef } from "react";
import Header from "./components/Header";
import HeroBanner from "./components/HeroBanner";
import LiveMatches from "./components/LiveMatches";
import UpcomingMatches from "./components/UpcomingMatches";
import StreamPlayer from "./components/StreamPlayer";
import Footer from "./components/Footer";
import { ApiMatch } from "./services/api";
import { useLiveMatches } from "./hooks/useLiveMatches";

export default function App() {
  const [selectedMatch, setSelectedMatch] = useState<ApiMatch | null>(null);
  const [activeTab, setActiveTab] = useState<"live" | "upcoming" | "finished">("live");
  const selectedIdRef = useRef<string | null>(null);

  const { liveMatches, upcomingMatches, finishedMatches, loading, error, lastUpdated, refresh } = useLiveMatches(45000);

  // Keep selectedMatch in sync with refreshed data — after every API refresh,
  // find the fresh version of the currently-selected match so the highlight
  // stays visible and stream data stays current.
  useEffect(() => {
    if (!selectedIdRef.current) return;
    const allMatches = [...liveMatches, ...upcomingMatches, ...finishedMatches];
    const fresh = allMatches.find((m) => m.id === selectedIdRef.current);
    if (fresh) {
      setSelectedMatch(fresh);
    }
  }, [liveMatches, upcomingMatches, finishedMatches]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        {/* Hero Banner */}
        <HeroBanner liveCount={liveMatches.length} />

        {/* Stream Player Section */}
        <StreamPlayer selectedMatch={selectedMatch} />

        {/* Tabs */}
        <div className="flex items-center gap-2 mb-6 mt-10 flex-wrap">
          <button
            onClick={() => setActiveTab("live")}
            className={`relative px-6 py-2.5 rounded-xl font-semibold text-sm transition-all duration-300 cursor-pointer ${
              activeTab === "live"
                ? "bg-red-600 text-white shadow-lg shadow-red-600/30"
                : "bg-white/5 text-slate-300 hover:bg-white/10"
            }`}
          >
            <span className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
              </span>
              Live Now
              {liveMatches.length > 0 && (
                <span className="ml-1 px-2 py-0.5 rounded-full bg-red-500/30 text-red-200 text-xs">
                  {liveMatches.length}
                </span>
              )}
            </span>
          </button>
          <button
            onClick={() => setActiveTab("upcoming")}
            className={`relative px-6 py-2.5 rounded-xl font-semibold text-sm transition-all duration-300 cursor-pointer ${
              activeTab === "upcoming"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                : "bg-white/5 text-slate-300 hover:bg-white/10"
            }`}
          >
            <span className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              Upcoming
              {upcomingMatches.length > 0 && (
                <span className="ml-1 px-2 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 text-xs">
                  {upcomingMatches.length}
                </span>
              )}
            </span>
          </button>
          <button
            onClick={() => setActiveTab("finished")}
            className={`relative px-6 py-2.5 rounded-xl font-semibold text-sm transition-all duration-300 cursor-pointer ${
              activeTab === "finished"
                ? "bg-slate-600 text-white shadow-lg shadow-slate-600/30"
                : "bg-white/5 text-slate-300 hover:bg-white/10"
            }`}
          >
            <span className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Results
              {finishedMatches.length > 0 && (
                <span className="ml-1 px-2 py-0.5 rounded-full bg-slate-500/30 text-slate-300 text-xs">
                  {finishedMatches.length}
                </span>
              )}
            </span>
          </button>

          {/* Refresh button & last updated */}
          <div className="ml-auto flex items-center gap-2">
            {lastUpdated && (
              <span className="text-xs text-slate-500">
                Updated {lastUpdated.toLocaleTimeString()}
              </span>
            )}
            <button
              onClick={refresh}
              disabled={loading}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer disabled:opacity-50"
              title="Refresh matches"
            >
              <svg className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>
          </div>
        </div>

        {/* Error Banner */}
        {error && (
          <div className="mb-4 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-start gap-3">
            <svg className="w-5 h-5 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div>
              <p className="font-semibold mb-0.5">Unable to load live matches</p>
              <p className="text-red-400/70">{error}. Using cached data — try refreshing.</p>
            </div>
          </div>
        )}

        {/* Matches Grid */}
        {loading && liveMatches.length === 0 && upcomingMatches.length === 0 && finishedMatches.length === 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="rounded-2xl border border-white/10 bg-white/5 p-5 animate-pulse">
                <div className="flex items-center justify-between mb-3">
                  <div className="h-4 w-20 bg-white/10 rounded-full"></div>
                  <div className="h-4 w-10 bg-white/10 rounded-full"></div>
                </div>
                <div className="flex items-center justify-between gap-4">
                  <div className="flex-1 text-center space-y-2">
                    <div className="w-10 h-10 mx-auto rounded-full bg-white/10"></div>
                    <div className="h-3 w-16 mx-auto bg-white/10 rounded"></div>
                  </div>
                  <div className="h-10 w-16 rounded-xl bg-white/10"></div>
                  <div className="flex-1 text-center space-y-2">
                    <div className="w-10 h-10 mx-auto rounded-full bg-white/10"></div>
                    <div className="h-3 w-16 mx-auto bg-white/10 rounded"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : activeTab === "live" ? (
          <LiveMatches
            matches={liveMatches}
            onSelectMatch={(match) => {
              selectedIdRef.current = match.id;
              setSelectedMatch(match);
            }}
            selectedMatch={selectedMatch}
          />
        ) : activeTab === "upcoming" ? (
          <UpcomingMatches
            matches={upcomingMatches}
            onSelectMatch={(match) => {
              selectedIdRef.current = match.id;
              setSelectedMatch(match);
            }}
            selectedMatch={selectedMatch}
          />
        ) : (
          <LiveMatches
            matches={finishedMatches}
            onSelectMatch={(match) => {
              selectedIdRef.current = match.id;
              setSelectedMatch(match);
            }}
            selectedMatch={selectedMatch}
            title="✅ Recent Results"
          />
        )}

        {/* Empty state — Live */}
        {!loading && activeTab === "live" && liveMatches.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white/5 flex items-center justify-center">
              <svg className="w-8 h-8 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-slate-400 font-medium">No live matches right now</p>
            <p className="text-slate-500 text-sm mt-1">Check the upcoming tab or come back later!</p>
          </div>
        )}

        {/* Empty state — Upcoming */}
        {!loading && activeTab === "upcoming" && upcomingMatches.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white/5 flex items-center justify-center">
              <svg className="w-8 h-8 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-slate-400 font-medium">No upcoming matches scheduled</p>
            <p className="text-slate-500 text-sm mt-1">Check back soon for new fixtures!</p>
          </div>
        )}

        {/* Empty state — Finished */}
        {!loading && activeTab === "finished" && finishedMatches.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white/5 flex items-center justify-center">
              <svg className="w-8 h-8 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <p className="text-slate-400 font-medium">No finished matches today</p>
            <p className="text-slate-500 text-sm mt-1">Results will appear here after matches end.</p>
          </div>
        )}

        {/* Disclaimer */}
        <section className="mt-8">
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-6">
            <div className="flex items-start gap-3">
              <svg className="w-6 h-6 text-amber-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div>
                <h4 className="font-semibold text-amber-400 mb-1">Disclaimer</h4>
                <p className="text-sm text-slate-300 leading-relaxed">
                  GoalStream does not host or broadcast any video content. We aggregate publicly available data from third-party APIs 
                  and provide links to external streaming servers. The availability and legality of streams may vary by region. 
                  We recommend using a VPN for privacy and checking your local laws regarding sports streaming. 
                  Always support official broadcasters when possible.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
